package com.example.goodgo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoodgoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoodgoApplication.class, args);
	}

}
