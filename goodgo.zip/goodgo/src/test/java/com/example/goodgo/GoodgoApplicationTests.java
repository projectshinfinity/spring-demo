package com.example.goodgo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoodgoApplicationTests {

	@Test
	void contextLoads() {
	}

}
